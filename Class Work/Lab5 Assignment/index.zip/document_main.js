/*var para = document.createElement("p");
var node = document.createTextNode("This is First Paragraph.");
para.appendChild(node);

var element = document.getElementById("firstDiv");
element.appendChild(para);


var para = document.createElement("p");
var node = document.createTextNode("This is Second Paragraph.");
para.appendChild(node);

var element = document.getElementById("firstDiv");
element.appendChild(para);


var para = document.createElement("p");
var node = document.createTextNode("This is Third Paragraph.");
para.appendChild(node);

var element = document.getElementById("firstDiv");
element.appendChild(para);


var para = document.createElement("p");
var node = document.createTextNode("This is Fourth Paragraph.");
para.appendChild(node);

var element = document.getElementById("firstDiv");
element.appendChild(para);


var para = document.createElement("p");
var node = document.createTextNode("This is Fifth Paragraph.");
para.appendChild(node);

var element = document.getElementById("firstDiv");
element.appendChild(para);


var para = document.createElement("p");
var node = document.createTextNode("This is Sixth Paragraph.");
para.appendChild(node);

var element = document.getElementById("firstDiv");
element.appendChild(para);


var para = document.createElement("p");
var node = document.createTextNode("This is Seventh Paragraph.");
para.appendChild(node);

var element = document.getElementById("firstDiv");
element.appendChild(para);


var para = document.createElement("p");
var node = document.createTextNode("This is Eighth Paragraph.");
para.appendChild(node);

var element = document.getElementById("firstDiv");
element.appendChild(para);


var para = document.createElement("p");
var node = document.createTextNode("This is Ninth Paragraph.");
para.appendChild(node);

var element = document.getElementById("firstDiv");
element.appendChild(para);


var para = document.createElement("p");
var node = document.createTextNode("This is Tenth Paragraph.");
para.appendChild(node);

var element = document.getElementById("firstDiv");
element.appendChild(para);*/


let firstPara = document.getElementById('para1');
let secondPara = document.getElementById('para2');
let thirdPara = document.getElementById('para3');
let fourthPara = document.getElementById('para4');
let fifthPara = document.getElementById('para5');
let sixthPara = document.getElementById('para6');
let seventhPara = document.getElementById('para7');
let eighthPara = document.getElementById('para8');
let ninthPara = document.getElementById('para9');
let tenthPara = document.getElementById('para10');

  setTimeout(function () {
      firstPara.innerText = 'This is First Paragraph.';
  }, 1000);





  setTimeout(function () {
      secondPara.innerText = 'This is Second Paragraph.';
  },2000);

  setTimeout(function () {
      thirdPara.innerText = 'This is Third Paragraph.';
  }, 3000);

  setTimeout(function () {
      fourthPara.innerText = 'This is Fourth Paragraph.';
  }, 4000);

  setTimeout(function () {
      fifthPara.innerText = 'This is Fifth Paragraph.';
  }, 5000);

  setTimeout(function () {
      sixthPara.innerText = 'This is Sixth Paragraph.';
  }, 6000);

  setTimeout(function () {
      seventhPara.innerText = 'This is Seventh Paragraph.';
  }, 7000);

  setTimeout(function () {
      eighthPara.innerText = 'This is Eighth Paragraph.';
  }, 8000);

  setTimeout(function () {
      ninthPara.innerText = 'This is Ninth Paragraph.';
  }, 9000);

  setTimeout(function () {
      tenthPara.innerText = 'This is Tenth Paragraph.';
  }, 10000);
